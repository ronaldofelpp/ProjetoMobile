export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCIX0deUMjqaS4SfSiJt_XjyQURRRTAENk",
    authDomain: "projetomobile-3c07a.firebaseapp.com",
    projectId: "projetomobile-3c07a",
    storageBucket: "projetomobile-3c07a.appspot.com",
    messagingSenderId: "1016059691737",
    appId: "1:1016059691737:web:e9d55c69fda3f46c28b4c8"
  }
};
